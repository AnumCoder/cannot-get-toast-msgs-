package com.xymbolic.login_signup_try;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class SignupActivity extends AppCompatActivity {


    public static final String TAG = "TAG";
    EditText mname;
    EditText memail;
    EditText mpassword;
    Button msignup;
    FirebaseAuth fAuth;
    ProgressBar progressBar;

    FirebaseFirestore fStore;
    String userid;

//    AwesomeValidation awesomeValidation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();


        mname = findViewById(R.id.name);
        memail = findViewById(R.id.email);
        mpassword = findViewById(R.id.password);
        msignup = findViewById(R.id.user_data_enter_signuppp);

        fStore = FirebaseFirestore.getInstance ();

        userid = fAuth.getCurrentUser ().getUid ();




        fAuth = FirebaseAuth.getInstance();

        progressBar = findViewById(R.id.progressBar2);


//
        if(fAuth.getCurrentUser() !=null)
        {
            Intent intent = new Intent(SignupActivity.this, MainApplication.class);
            startActivity(intent);
            finish();
        }


        msignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String name = mname.getText().toString();
             final String email = memail.getText().toString().trim();
             String password = mpassword.getText().toString().trim();



             if(TextUtils.isEmpty(email))
             {
                 memail.setError("please enter Email");
//                 memail.setText("Please enter Email address. ");
                 return;
             }

             if(TextUtils.isEmpty(password))
             {
                 mpassword.setError("please enter Password");
//                 mpassword.setText("password is required");
                 return;
             }

             if(password.length() < 6 )
             {
                 mpassword.setError("Password must be greater ot equal than 6 characters.");
               //  mpassword.setText("Password must be greater ot equal than 6 characters. ");
                 return;
             }

             progressBar.setVisibility(View.VISIBLE);


             //registering user in firebase

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {


                            userid = fAuth.getCurrentUser ().getUid ();

                        DocumentReference documentReference = fStore.collection ("users").document (userid);
                        Map<String,Object> fuser = new HashMap<> ();

                        fuser.put ("name",name);

                            fuser.put ("email",email);

                            documentReference.set (fuser).addOnSuccessListener (new OnSuccessListener<Void> () {
                                @Override
                                public void onSuccess(Void aVoid) {

                                    Log.d (TAG, "onSuccess: user profile is created for "+userid);

                                }
                            }).addOnFailureListener (new OnFailureListener () {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d (TAG, "onFailure: " + e.toString ());
                                }
                            });

                            FirebaseUser user = fAuth.getCurrentUser ();
                            user.sendEmailVerification ().addOnSuccessListener (new OnSuccessListener<Void> () {
                                @Override
                                public void onSuccess(Void aVoid) {


                                    Toast.makeText (SignupActivity.this, "Verification Email Has been sent", Toast.LENGTH_SHORT).show ();
                                }
                            }).addOnFailureListener (new OnFailureListener () {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                    Log.d (TAG, "onFailure: Email Not Sent!" + e.getMessage ());
                                }
                            });


                            Toast.makeText(SignupActivity.this,"user created",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(SignupActivity.this, MainApplication.class);
                            startActivity(intent);
                        }
                        else
                        {
                            Toast.makeText(SignupActivity.this,"Error ! "+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });

            }
        });



    }
}

//        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
//
//        // validation for name
//
//        awesomeValidation.addValidation(this,R.id.name,
//                RegexTemplate.NOT_EMPTY,R.string.invalid_name);
//
//
//        // For Mobile No
////        awesomeValidation.addValidation(this,R.id.mobile,
////        "[5-9]{1}{0-9}$",R.string.invalid_mobile);
////        https://www.youtube.com/watch?v=FjRKF05npoo
//////        video from 15:50 FOR EMAIL ALSO
//
//        // for password
//
//        awesomeValidation.addValidation(this,R.id.password,
//                ".{6,}",R.string.invalid_password);
//
//        // for confirm password
//
////        awesomeValidation.addValidation(this,R.id.confirm_pass,
////            R.id.confirm_pass,R.string.invalid_password);
//
//
//
//        //for email
//
//
//        awesomeValidation.addValidation(this,R.id.email,
//                Patterns.EMAIL_ADDRESS,R.string.invalid_email);
//
//
//
//        signup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // checking reg ex
//
//                if(awesomeValidation.validate())
//                {
//                    // agar hojata hai sb sai to
//
//                    Toast.makeText(getApplicationContext()
//                            ,"valid information",Toast.LENGTH_SHORT).show();
//
//                    insert();
//
//
//                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
//                    startActivity(intent);
//
//                  }
//
//
//                else
//                {
//                    Toast.makeText(getApplicationContext()
//                            , "Invalid Information",Toast.LENGTH_SHORT).show();
//                }
//
//
//
//
//
//
//
//
//            }
//        });
//
////        getSupportActionBar().setTitle(" Join us :) ");
//
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
//                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
//        getWindow().setStatusBarColor(Color.TRANSPARENT);
//
//    }
//
//    public void insert()
//    {
//        try{
//
//            String username = name.getText().toString();
//            String e_mail = email.getText().toString();
//            String Password = password.getText().toString();
//
//            SQLiteDatabase db = openOrCreateDatabase("toy", Context.MODE_PRIVATE,null);
//            db.execSQL("CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY AUTOINCREMENT, Name VARCHAR, Email VARCHAR, Pass VARCHAR)");
//
//            String sql = "insert into user(Name, Email, Pass) values(?,?,?)";
//            SQLiteStatement statement = db.compileStatement(sql);
//            statement.bindString(1,username);
//            statement.bindString(1,e_mail);
//            statement.bindString(1,Password);
//            statement.execute();
//            Toast.makeText(this,"Record Added",Toast.LENGTH_LONG).show();
//
//          name.setText("");
//          email.setText("");
//          password.setText("");
//          name.requestFocus();
//
//
//
//        }catch (Exception e)
//        {
//            Toast.makeText(this,"App Error",Toast.LENGTH_LONG).show();
//
//            e.printStackTrace();
//        }
//    }
// ................................................................
// yh neche 2 bracket closing hain... jb htao cmnt to inko dkh lena andhi
//    }
//}
//...............................................