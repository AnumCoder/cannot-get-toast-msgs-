package com.xymbolic.login_signup_try;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {


    TextView signup;
    EditText memail;
    EditText mpassword;
    Button mlogin;
    FirebaseAuth fAuth;
    ProgressBar progressBar;

    TextView forgotPassword;

    AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getSupportActionBar().hide();

//        getSupportActionBar().setTitle(" Login :) ");


//        yh back arrow key k lie use hta hai jo abhi nahi chahaie
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        signup = findViewById(R.id.signup);
        memail = findViewById(R.id.email);
        mpassword = findViewById(R.id.pass_login);
        mlogin = findViewById(R.id.login);

        fAuth = FirebaseAuth.getInstance();

        progressBar = findViewById(R.id.progressBar);

        forgotPassword = findViewById (R.id.forgotpassword);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, SignupActivity.class);
                startActivity(intent);

            }
        });


        if(fAuth.getCurrentUser() !=null)
        {
            Intent intent = new Intent(MainActivity.this, MainApplication.class);
            startActivity(intent);
            finish();
        }


        mlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = memail.getText().toString().trim();
                String password = mpassword.getText().toString().trim();

                if(TextUtils.isEmpty(email))
                {
                    memail.setError("please enter Email");
//                 memail.setText("Please enter Email address. ");

                    return;
                }

                if(TextUtils.isEmpty(password))
                {
                    mpassword.setError("please enter Password");
//                 mpassword.setText("password is required");
                    return;
                }
                if(password.length() < 6 )
                {
                    mpassword.setError("Password must be greater ot equal than 6 characters.");
                    //  mpassword.setText("Password must be greater ot equal than 6 characters. ");
                    return;
                }

                progressBar.setVisibility (View.VISIBLE);


                fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {


                        if(task.isSuccessful())
                        {
                            Toast.makeText(MainActivity.this,"Logged in successfully",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, MainApplication.class);
                            startActivity(intent);
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this,"Error ! "+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }

                    }
                });

            }

            });


        forgotPassword.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                final EditText resetmail = new EditText (v.getContext ());
                final AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder (v.getContext ());
                passwordResetDialog.setTitle ("Reset password ? ");
                passwordResetDialog.setMessage ("Enter Your Email to receive reset link");
                passwordResetDialog.setView(resetmail);

//                Toast.makeText (MainActivity.this,"checking",Toast.LENGTH_SHORT).show();

                passwordResetDialog.setPositiveButton ("yes", new DialogInterface.OnClickListener () {


                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // email le k link wapis dena hai

//                        Toast.makeText (MainActivity.this,"yes press hua hai",Toast.LENGTH_SHORT).show();

                        String mail = resetmail.getText ().toString ();
                        fAuth.sendPasswordResetEmail (mail).addOnSuccessListener (new OnSuccessListener<Void> () {
                            @Override
                            public void onSuccess(Void aVoid) {

                                Toast.makeText (MainActivity.this, "Reset password link is sent to your Email! ", Toast.LENGTH_LONG).show ();
                            }
                        }).addOnFailureListener (new OnFailureListener () {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Toast.makeText (MainActivity.this, "Error !!! Can not sent mail" + e.getMessage (), Toast.LENGTH_LONG).show ();

                            }
                        });
                    }
                }).setNegativeButton ("No", new DialogInterface.OnClickListener () {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // jb No kr de ga to kuch  b ni hoga


                    }
                });

                passwordResetDialog.create ().show ();

            }
        });

    }
}
//        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
//
//        // validation for name
//
//        awesomeValidation.addValidation(this, R.id.uname_login,
//                RegexTemplate.NOT_EMPTY, R.string.invalid_name);
//
//
//        // For Mobile No
////        awesomeValidation.addValidation(this,R.id.mobile,
////        "[5-9]{1}{0-9}$",R.string.invalid_mobile);
////        https://www.youtube.com/watch?v=FjRKF05npoo
//////        video from 15:50 FOR EMAIL ALSO
//
//        // for password
//
//        awesomeValidation.addValidation(this, R.id.pass_login,
//                ".{6,}", R.string.invalid_password);
//
//        // for confirm password
//
////        awesomeValidation.addValidation(this,R.id.confirm_pass,
////            R.id.confirm_pass,R.string.invalid_password);
//
//
//        login.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // checking reg ex
////
//
//
//                if (awesomeValidation.validate())
//                {
//                    // agar hojata hai sb sai to
//
//                    Toast.makeText(getApplicationContext()
//                            , "valid information", Toast.LENGTH_SHORT).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext()
//                            , "Invalid Information", Toast.LENGTH_SHORT).show();
//                }
//
//                Intent intent = new Intent(MainActivity.this, MainApplication.class);
//                startActivity(intent);
//
//
////                login();
//            }
//        });
//
//
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
//                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
//        getWindow().setStatusBarColor(Color.TRANSPARENT);
//
//
//
//    }


//    public void login() {
//        String user = uname.getText().toString();
//        String Pass = password.getText().toString();
//
//
//        if (user.equals("") || Pass.equals(""))
//        {
//
//                Toast.makeText(this, "user name or password is empty", Toast.LENGTH_LONG).show();
//        }
//
//        else if (null != checkuser(user, Pass)) {
//
//
//                String userDB = checkuser(user, Pass);
//             //   Intent i = new Intent(MainActivity.this, MainApplication.class);
//
//            Intent i = new Intent(MainActivity.this, SignupActivity.class);
//                i.putExtra("uname", userDB);
//                startActivity(i);
//
//
//            } else {
//                Toast.makeText(this, "user name or password is incorrect ", Toast.LENGTH_LONG).show();
//                uname.setText("");
//                password.setText("");
//                uname.requestFocus();
//
//            }
//        }
//
//        public String checkuser(String user, String Pass)
//        {
//            SQLiteDatabase db = openOrCreateDatabase("toy", Context.MODE_PRIVATE, null);
//            Cursor cursor = db.rawQuery("select id,Name,Pass from username where username = ? and Password = ?", new String[]{user, Pass});
//
//            if (cursor.getCount() > 0) {
//                cursor.moveToFirst();
//                String username = cursor.getString(1);
//                String password = cursor.getString(2);
//                SharedPreferences.Editor ap = getSharedPreferences(username, MODE_PRIVATE).edit();
//                ap.putString("uname", username);
//                ap.apply();
//                cursor.close();
//                return username;
//
//            }
//            return null;
//        }
//
//    }
